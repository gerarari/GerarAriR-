@extends('company.master')
@section('content')
<div class="content">
         <div class="container-fluid">
             <div class="row">
                 <div class="col-md-4">
                     <div class="card">
                         <div class="header">
                             <h4 class="title">Heading here</h4>
                             <p class="category">sub heading here</p>
                         </div>
                         <div class="content">


                             <div class="footer">
                                 <div class="legend">

                                 </div>
                                 <hr>
                                 <div class="stats">

                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>

                 <div class="col-md-8">
                     <div class="card">
                         <div class="header">
                           <h4 class="title">Heading here</h4>
                           <p class="category">sub heading here</p>
                         </div>
                         <div class="content">

                             <div class="footer">
                                 <div class="legend">

                                  </div>
                                 <hr>
                                 <div class="stats">

                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>



         </div>
     </div>
     @endsection
